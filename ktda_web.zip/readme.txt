adding new user.
add his detaile profile in ktda
unique the way you said
adding kembo trips...
16/= per kilo...
100 * 16 = 1600

let kembo now log to his account.

done.